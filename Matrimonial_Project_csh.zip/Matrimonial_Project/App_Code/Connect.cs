using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

/// <summary>
/// Summary description for Connection
/// </summary>
public class Connect
{
    SqlCommand cmd;
    SqlConnection con;
    SqlDataAdapter da;
    DataTable dt;
    DataSet ds;

    public SqlConnection GetConnection()
    {
        con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=I:\Matrimoni_Project\App_Data\Lifepatner.mdf;Integrated Security=True;User Instance=True");
        return con;
    }

}
