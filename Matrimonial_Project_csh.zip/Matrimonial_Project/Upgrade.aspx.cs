using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Upgrade : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }
    protected void RadioButton5_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void R3500_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void R6100_CheckedChanged(object sender, EventArgs e)
    {
        
    }
    protected void R3100_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void R7000_CheckedChanged(object sender, EventArgs e)
    {
        
    }
    protected void R2400_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void R4200_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void R5400_CheckedChanged(object sender, EventArgs e)
    {
        
    }
    protected void BRegistration_Click(object sender, EventArgs e)
    {
        Response.Redirect("BankAcc.aspx");
    }
}
